#!/bin/bash
set -x

python3 gateway.py

