# WepSIM


## Pre-requisites

```
pip install flask flask-cors
```

